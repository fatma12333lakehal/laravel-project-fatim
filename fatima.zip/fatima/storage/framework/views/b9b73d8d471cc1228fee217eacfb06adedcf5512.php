<!DOCTYPE html>
<html class="no-js" lang="en">
<head>

    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <title>Fatma lakehal</title>
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- mobile specific metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="epi/css/base.css">
    <link rel="stylesheet" href="epi/css/vendor.css">
    <link rel="stylesheet" href="epi/css/main.css">

    <!-- script
    ================================================== -->
    <script src="epi/js/modernizr.js"></script>
    <script src="epi/js/pace.min.js"></script>

    <!-- favicons
    ================================================== -->
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="epi/image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="epi/image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">

</head>

<body id="top">

    <div id="preloader">
        <div id="loader"></div>
    </div>

    <!-- site header
    ================================================== -->
    <header class="s-header">

        

        <nav class="header-nav-wrap">
            <ul class="header-main-nav">
                <li class="current"><a class="smoothscroll" href="#intro" title="intro">Intro</a></li>
                <li><a class="smoothscroll" href="#about" title="about">About</a></li>
                <li><a class="smoothscroll" href="#services" title="services">Services</a></li>
                <li><a class="smoothscroll" href="#works" title="works">Works</a></li>
                <li><a class="smoothscroll" href="#contact" title="contact us">Say Hello</a></li>	
            </ul>

            <ul class="header-social">
                <li><a href="#0"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
                <li><a href="#0"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                <li><a href="#0"><i class="fab fa-dribbble" aria-hidden="true"></i></a></li>
                <li><a href="#0"><i class="fab fa-behance" aria-hidden="true"></i></a></li>
            </ul>
        </nav>

        <a class="header-menu-toggle" href="#"><span>Menu</span></a>

    </header> <!-- end s-header -->


    <!-- intro
    ================================================== -->
    <section id="intro" class="s-intro target-section">

        <div class="row intro-content">

            <div class="column large-9 mob-full intro-text">
                <h3>Hello, I'm fatma zahra lakehal</h3>
                <h1>
                  Software  Engineer <br>
                    and Web Developer <br>
                    Based In Somewhere.
                </h1>
            </div>

            <div class="intro-scroll">
                <a href="#about" class="intro-scroll-link smoothscroll">
                    Scroll For More
                </a>
            </div>

            <div class="intro-grid"></div>
            <div class="intro-pic"></div>

        </div> <!-- end row -->

    </section> <!-- end intro -->


    <!-- about
    ================================================== -->
    <section id="about" class="s-about target-section">

        <div class="about-me">

            <div class="row heading-block" data-aos="fade-up">
                <div class="column large-full">
                    <h2 class="section-heading">About Me</h2>
                </div>
            </div>

            <div class="row about-me__content" data-aos="fade-up">
                <div class="column large-full about-me__text">
                    <p class="lead">
                    Welcome to my online portfolio!

                     Curious, strict and punctual, I'm fascinated by the new techniques. In addition to their modus operas, I am interested in understanding the potential effects when used in complex and/or critical environments.
                    </p>

                    <p>
                    My name is fatma zahra lakehal I'm 26 years old . 
                    I'm software engineer.I program websites and desktop apps on demand . 
                    I've created several websites and computer applications for many companies and members. I have several loyal customers worldwide . 
                    
                    </p>

                    <p>
                    Programming is love, patience and perseverance.
                    The most important thing for the programmer is to win the trust of the customer and facilitate the lives of human beings.. by always thinking about the problems of humans and proposing solutions .
                    </p>

                    
                </div>
            </div>
    
           

        </div> <!-- end about-me -->

        <div class="about-experience">

            <div class="row heading-block" data-aos="fade-up">
                <div class="column large-full">
                    <h2 class="section-heading">Work & Education</h2>
                </div>
            </div>

            <div class="row about-experience__timeline">

                <div class="column large-half tab-full" data-aos="fade-up">
                    <div class="timeline">

                        <div class="timeline__icon-wrap">
                            <span class="timeline__icon timeline__icon--work"></span>
                        </div>

                        <div class="timeline__block">
                            <div class="timeline__bullet"></div>
                            <div class="timeline__header">
                                <p class="timeline__timeframe">July 2020 - Present</p>
                                <h3 class="item-title">Software Engineer  </h3>
                                <h5>developer</h5>
                            </div>
                           
                        </div>

                        <div class="timeline__block">
                            <div class="timeline__bullet"></div>
                            <div class="timeline__header">
                                <p class="timeline__timeframe">July 2017 - June 2018</p>
                                <h3 class="item-title">
                                Frontend Developer
                                </h3>
                                
                            </div>
                            <div class="timeline__desc">
                                
                            </div>
                        </div>

                       

                    </div>
                </div>

                <div class="column large-half tab-full" data-aos="fade-up">
                    <div class="timeline">

                        <div class="timeline__icon-wrap">
                            <span class="timeline__icon timeline__icon--education"></span>
                        </div>

                        <div class="timeline__block">
                            <div class="timeline__bullet"></div>
                            <div class="timeline__header">
                                <p class="timeline__timeframe">July 2015 - June 2020</p>
                                <h3 class="item-title">University of Computer science</h3>
                                <h5>Master Degree</h5>
                            </div>
                            <div class="timeline__desc">
                                
                            </div>
                        </div>

                        <div class="timeline__block">
                            <div class="timeline__bullet"></div>
                            <div class="timeline__header">
                                <p class="timeline__timeframe"> June 2015</p>
                                <h3 class="item-title">hight school</h3>
                                <h5>Bachelor Degree</h5>
                            </div>
                            <div class="timeline__desc">
                                <p></p>
                            </div>
                        </div>

                        

                    </div>
                </div>
            </div>

        </div> <!-- end about-experience -->

    </section> <!-- end s-about -->


    <!-- services
    ================================================== -->
    <section id="services" class="s-services ss-dark target-section">

        <div class="shadow-overlay"></div>

        <div class="row heading-block heading-block--center" data-aos="fade-up">
            <div class="column large-full">
                <h2 class="section-heading section-heading--centerbottom">Capabilities</h2>

                <p class="section-desc">
                    My passion and goal is to help you make your websites and desktop apps on demand.
                </p>
            </div>
        </div> <!-- end heading-block -->

        <div class="row services-list block-large-1-3 block-medium-1-2 block-tab-full">

            <div class="column item-service" data-aos="fade-up">
                <div class="item-service__content">
                    <h4 class="item-title">Portfolio</h4>
                    <p>
                    
                    </p>
                </div>
            </div>

            <div class="column item-service" data-aos="fade-up">
                <div class="item-service__content">
                    <h4 class="item-title">Web Design</h4>
                    <p>
                   .
                    </p>
                </div>
            </div>

            <div class="column item-service" data-aos="fade-up">
                <div class="item-service__content">
                    <h4 class="item-title">application desktop</h4>
                    <p>
                    
                    </p>
                </div>
            </div>

            <div class="column item-service" data-aos="fade-up">
                <div class="item-service__content">
                    <h4 class="item-title">Mobile Design</h4>
                    <p>
                   
                    </p>
                </div>
            </div>

            <div class="column item-service" data-aos="fade-up">
                <div class="item-service__content">
                    <h4 class="item-title">UI/UX Design</h4>
                    <p>
                   
                    </p>
                </div>
            </div>

           

        </div> <!-- end services-list -->

    </section> <!-- end s-services -->


    <!-- CTA
    ================================================== -->
    <section class="s-cta ss-dark">

        <div class="row heading-block heading-block--center" data-aos="fade-up">
            <div class="column large-full">
                <h2 class="section-desc">
                    Need a website or desktop app or porfolio?
                </h2>
            </div>
        </div> <!-- end heading-block -->

        <div class="row cta-content" data-aos="fade-up">
            <div class="column large-full">
                

                <a href="https://www.dreamhost.com/r.cgi?287326" class="btn full-width">Inbox me</a>
            </div>
        </div> <!-- end ad-content -->

    </section> <!-- end s-cta -->


    <!-- works
    ================================================== -->
    


    <!-- testimonies
    ================================================== -->
    


    <!-- contact
    ================================================== -->
    <section id="contact" class="s-contact ss-dark target-section">

        <div class="row heading-block" data-aos="fade-up">
            <div class="column large-full">
                <h2 class="section-heading">Get In Touch</h2>
            </div>
        </div>

        <div class="row contact-main" data-aos="fade-up">
            <div class="column large-full">
                <p class="contact-email">
                    <a href="mailto:#0">fatimalakvvc@gmail.com</a>
                </p>

                <p class="section-desc">
                I'm happy to connect, listen and help. Let's work together and build
                something awesome. Let's turn your idea to an even greater product.
                <a href="mailto:#0">Email Me</a>.
                </p>
            </div>
        </div>

        <div class="row contact-infos" data-aos="fade-up" data-aos-anchor=".contact-main">

            <div class="column large-5 medium-full contact-phone">
                <h4>Call Me</h4>
                <a href="tel:197-543-2345">+213 0776048341</a>
            </div>

            <div class="column large-7 medium-full contact-social">
                <h4>Social</h4>
                <ul>
                    <li><a href="#0" title="Facebook">Facebook</a></li>
                    <li><a href="#0" title="Twitter">Twitter</a></li>
                    <li><a href="#0" title="Instagram">Instagram</a></li>
                </ul>
            </div>

        </div> <!-- end contact-infos -->

    </section> <!-- end s-contact -->


    <!-- footer
    ================================================== -->
    <footer>
        <div class="row">
            <div class="column large-full ss-copyright">
                <span></span> 
                <span>Design by <a href="#"></a></span>
            </div>            

            <div class="ss-go-top">
                <a class="smoothscroll" title="Back to Top" href="#top"></a>
            </div>
        </div>
    </footer>


    <!-- photoswipe background
    ================================================== -->
    <div aria-hidden="true" class="pswp" role="dialog" tabindex="-1">

        <div class="pswp__bg"></div>
        <div class="pswp__scroll-wrap">

            <div class="pswp__container">
                <div class="pswp__item"></div>
                <div class="pswp__item"></div>
                <div class="pswp__item"></div>
            </div>

            <div class="pswp__ui pswp__ui--hidden">
                <div class="pswp__top-bar">
                    <div class="pswp__counter"></div><button class="pswp__button pswp__button--close" title="Close (Esc)"></button> <button class="pswp__button pswp__button--share" title=
                    "Share"></button> <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button> <button class="pswp__button pswp__button--zoom" title=
                    "Zoom in/out"></button>
                    <div class="pswp__preloader">
                        <div class="pswp__preloader__icn">
                            <div class="pswp__preloader__cut">
                                <div class="pswp__preloader__donut"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                    <div class="pswp__share-tooltip"></div>
                </div><button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)"></button> <button class="pswp__button pswp__button--arrow--right" title=
                "Next (arrow right)"></button>
                <div class="pswp__caption">
                    <div class="pswp__caption__center"></div>
                </div>
            </div>

        </div>

    </div><!-- end photoSwipe background -->


    <!-- Java Script
    ================================================== -->
    <script src="epi/js/jquery-3.2.1.min.js"></script>
    <script src="epi/js/plugins.js"></script>
    <script src="epi/js/main.js"></script>

</body><?php /**PATH C:\Users\Dell\fatima\resources\views/index.blade.php ENDPATH**/ ?>